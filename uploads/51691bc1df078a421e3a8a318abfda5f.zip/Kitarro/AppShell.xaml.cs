using Kitarro.Pages;

namespace Kitarro;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        // Pages that are pushed on top of a tab (not part of the bottom bar)
        Routing.RegisterRoute("milestones", typeof(MilestonesPage));
        Routing.RegisterRoute("profile", typeof(ProfilePage));
        Routing.RegisterRoute("settings", typeof(SettingsPage));
    }
}
