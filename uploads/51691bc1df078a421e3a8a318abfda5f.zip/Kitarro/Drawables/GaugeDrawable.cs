namespace Kitarro.Drawables;

/// <summary>Circular progress gauge on the Milestones page ("97% monthly goal").</summary>
public class GaugeDrawable : IDrawable
{
    public double Progress { get; set; }

    public void Draw(ICanvas canvas, RectF dirtyRect)
    {
        const float stroke = 9f;
        var size = Math.Min(dirtyRect.Width, dirtyRect.Height) - stroke * 2;
        var x = dirtyRect.Center.X - size / 2;
        var y = dirtyRect.Center.Y - size / 2;

        // Track
        canvas.StrokeSize = stroke;
        canvas.StrokeLineCap = LineCap.Round;
        canvas.StrokeColor = Color.FromRgba(255, 255, 255, 60);
        canvas.DrawEllipse(x, y, size, size);

        // Progress arc, starting at 12 o'clock and going clockwise
        var p = Math.Clamp(Progress, 0, 0.999);
        if (p > 0)
        {
            canvas.StrokeColor = Colors.White;
            var end = (float)(90 - 360 * p);
            if (end < 0) end += 360;
            canvas.DrawArc(x, y, size, size, 90, end, true, false);
        }

        // Percentage text in the middle
        canvas.FontColor = Colors.White;
        canvas.FontSize = 22;
        canvas.DrawString($"{Math.Round(Progress * 100):0}%",
            dirtyRect.Center.X - 40, dirtyRect.Center.Y - 20, 80, 26,
            HorizontalAlignment.Center, VerticalAlignment.Center);

        canvas.FontSize = 9;
        canvas.DrawString("OF GOAL",
            dirtyRect.Center.X - 40, dirtyRect.Center.Y + 6, 80, 14,
            HorizontalAlignment.Center, VerticalAlignment.Center);
    }
}
