using Kitarro.Models;

namespace Kitarro.Drawables;

/// <summary>
/// Stylised map preview for the Stations page. Station pins are placed from their real latitude/longitude,
/// so no map SDK or API key is needed. Tapping a pin selects the station.
/// </summary>
public class StationMapDrawable : IDrawable
{
    public IReadOnlyList<Station> Stations { get; set; } = Array.Empty<Station>();
    public double UserLat { get; set; }
    public double UserLng { get; set; }
    public bool HasUser { get; set; }

    private RectF _lastRect;

    public void Draw(ICanvas canvas, RectF rect)
    {
        _lastRect = rect;

        // Background "land"
        canvas.FillColor = Color.FromArgb("#E6EFE4");
        canvas.FillRectangle(rect);

        // Soft park blob and river for a map feeling
        canvas.FillColor = Color.FromArgb("#D3E4D0");
        canvas.FillEllipse(rect.Width * 0.58f, rect.Height * 0.08f, rect.Width * 0.34f, rect.Height * 0.36f);
        canvas.StrokeColor = Color.FromArgb("#C9DDE6");
        canvas.StrokeSize = 10;
        var river = new PathF();
        river.MoveTo(0, rect.Height * 0.78f);
        river.CurveTo(rect.Width * 0.3f, rect.Height * 0.55f, rect.Width * 0.6f, rect.Height * 1.0f, rect.Width, rect.Height * 0.62f);
        canvas.DrawPath(river);

        // Road grid
        canvas.StrokeColor = Colors.White;
        canvas.StrokeSize = 5;
        for (var i = 1; i < 4; i++)
        {
            canvas.DrawLine(rect.Width * i / 4f, 0, rect.Width * (i / 4f + 0.06f), rect.Height);
            canvas.DrawLine(0, rect.Height * i / 4f, rect.Width, rect.Height * (i / 4f - 0.04f));
        }

        // Pins
        foreach (var s in Stations)
        {
            var p = Project(s.Latitude, s.Longitude, rect);
            DrawPin(canvas, p, s.IsSelected);
        }

        // User location (blue dot with halo)
        if (HasUser)
        {
            var u = Project(UserLat, UserLng, rect);
            canvas.FillColor = Color.FromRgba(66, 133, 244, 60);
            canvas.FillCircle(u, 16);
            canvas.FillColor = Colors.White;
            canvas.FillCircle(u, 8);
            canvas.FillColor = Color.FromArgb("#4285F4");
            canvas.FillCircle(u, 6);
        }
    }

    private static void DrawPin(ICanvas canvas, PointF p, bool selected)
    {
        var r = selected ? 13f : 10f;
        canvas.FillColor = Color.FromRgba(0, 0, 0, 40);
        canvas.FillCircle(p.X + 1.5f, p.Y + 2.5f, r);
        canvas.FillColor = selected ? Color.FromArgb("#E8913A") : Color.FromArgb("#5B7360");
        canvas.FillCircle(p, r);
        canvas.FillColor = Colors.White;
        canvas.FillCircle(p, r * 0.4f);
    }

    /// <summary>Turns latitude/longitude into x/y inside the map, using the area covered by the stations.</summary>
    private PointF Project(double lat, double lng, RectF rect)
    {
        var lats = Stations.Select(s => s.Latitude).ToList();
        var lngs = Stations.Select(s => s.Longitude).ToList();
        if (HasUser) { lats.Add(UserLat); lngs.Add(UserLng); }
        if (lats.Count == 0) return new PointF(rect.Center.X, rect.Center.Y);

        var minLat = lats.Min(); var maxLat = lats.Max();
        var minLng = lngs.Min(); var maxLng = lngs.Max();
        var latSpan = Math.Max(maxLat - minLat, 0.005);
        var lngSpan = Math.Max(maxLng - minLng, 0.005);

        const float pad = 28f;
        var x = pad + (lng - minLng) / lngSpan * (rect.Width - pad * 2);
        var y = pad + (maxLat - lat) / latSpan * (rect.Height - pad * 2);   // north is up
        return new PointF((float)x, (float)y);
    }

    /// <summary>Returns the station whose pin is closest to the tap (within 30 px), or null.</summary>
    public Station? HitTest(PointF tap)
    {
        Station? best = null;
        var bestDist = 30f;
        foreach (var s in Stations)
        {
            var p = Project(s.Latitude, s.Longitude, _lastRect);
            var d = MathF.Sqrt((p.X - tap.X) * (p.X - tap.X) + (p.Y - tap.Y) * (p.Y - tap.Y));
            if (d < bestDist) { bestDist = d; best = s; }
        }
        return best;
    }
}
