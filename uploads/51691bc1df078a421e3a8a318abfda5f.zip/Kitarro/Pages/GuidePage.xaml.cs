using Kitarro.ViewModels;

namespace Kitarro.Pages;

public partial class GuidePage : ContentPage
{
    public GuidePage(GuideViewModel vm)
    {
        InitializeComponent();
        BindingContext = vm;
    }
}
