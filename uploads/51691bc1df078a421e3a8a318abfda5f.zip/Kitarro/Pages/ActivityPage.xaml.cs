using Kitarro.ViewModels;

namespace Kitarro.Pages;

public partial class ActivityPage : ContentPage
{
    private readonly ActivityViewModel _vm;

    public ActivityPage(ActivityViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.LoadAsync();
    }
}
