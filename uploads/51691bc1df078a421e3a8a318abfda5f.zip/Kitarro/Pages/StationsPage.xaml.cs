using Kitarro.Drawables;
using Kitarro.ViewModels;

namespace Kitarro.Pages;

public partial class StationsPage : ContentPage
{
    private readonly StationsViewModel _vm;
    private readonly StationMapDrawable _map = new();
    private bool _askedForLocation;

    public StationsPage(StationsViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;

        _map.Stations = _vm.AllStations;
        MapView.Drawable = _map;

        // Tap on the map = select the nearest pin (gesture on a custom-drawn view).
        MapView.StartInteraction += (_, e) =>
        {
            var touch = e.Touches.FirstOrDefault();
            _vm.Select(_map.HitTest(touch));
        };

        // The view model says when the map must be redrawn (filter, selection, GPS).
        _vm.MapChanged += RedrawMap;
    }

    private void RedrawMap()
    {
        _map.HasUser = _vm.HasUserLocation;
        _map.UserLat = _vm.UserLat;
        _map.UserLng = _vm.UserLng;
        MapView.Invalidate();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.LoadAsync();

        // Try the GPS once, quietly. The target button asks again with messages.
        if (!_askedForLocation)
        {
            _askedForLocation = true;
            await _vm.LocateAsync(showMessages: false);
        }
    }
}
