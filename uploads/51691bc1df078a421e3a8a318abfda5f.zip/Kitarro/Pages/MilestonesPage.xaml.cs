using Kitarro.ViewModels;

namespace Kitarro.Pages;

public partial class MilestonesPage : ContentPage
{
    private readonly MilestonesViewModel _vm;

    public MilestonesPage(MilestonesViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;

        GaugeView.Drawable = _vm.Gauge;
        _vm.GaugeChanged += () => GaugeView.Invalidate();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.LoadAsync();
    }
}
