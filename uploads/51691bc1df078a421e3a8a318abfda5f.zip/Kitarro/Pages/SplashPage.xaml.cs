using Kitarro.ViewModels;

namespace Kitarro.Pages;

public partial class SplashPage : ContentPage
{
    private readonly SplashViewModel _vm;

    public SplashPage(SplashViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        // Fade/zoom the logo in while the saved session is checked.
        // (FadeTo/ScaleTo exist on .NET 8, 9 and 10; on .NET 10 they only show an "obsolete" warning.)
        _ = LogoImage.FadeTo(1, 700);
        _ = LogoImage.ScaleTo(1, 700, Easing.CubicOut);
        await Task.Delay(300);
        _ = TitleLabel.FadeTo(1, 600);
        _ = SubtitleLabel.FadeTo(1, 800);

        var route = await _vm.DecideNextRouteAsync();
        await Shell.Current.GoToAsync(route);
    }
}
