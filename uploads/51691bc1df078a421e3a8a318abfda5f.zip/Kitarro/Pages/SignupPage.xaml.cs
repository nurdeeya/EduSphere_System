using Kitarro.ViewModels;

namespace Kitarro.Pages;

public partial class SignupPage : ContentPage
{
    private readonly SignupViewModel _vm;

    public SignupPage(SignupViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _vm.Reset();
    }
}
