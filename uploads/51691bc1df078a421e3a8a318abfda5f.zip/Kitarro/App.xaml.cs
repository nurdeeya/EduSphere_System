using Kitarro.Services;

namespace Kitarro;

public partial class App : Application
{
    public App(SettingsService settings)
    {
        InitializeComponent();
        settings.ApplyAll();   // theme + text size saved by the user
    }

    protected override Window CreateWindow(IActivationState? activationState)
        => new Window(new AppShell());
}
