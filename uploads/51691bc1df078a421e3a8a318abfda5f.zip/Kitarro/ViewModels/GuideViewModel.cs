using System.Collections.ObjectModel;
using System.Windows.Input;
using Kitarro.Models;
using Kitarro.Services;

namespace Kitarro.ViewModels;

/// <summary>A filter chip (All, Plastics, Paper...). Selected chip is highlighted.</summary>
public class FilterChip : BaseViewModel
{
    public string Name { get; }
    public FilterChip(string name, bool selected = false) { Name = name; _isSelected = selected; }

    private bool _isSelected;
    public bool IsSelected
    {
        get => _isSelected;
        set { if (Set(ref _isSelected, value)) OnPropertyChanged(nameof(IsNotSelected)); }
    }
    public bool IsNotSelected => !IsSelected;
}

public class GuideViewModel : BaseViewModel
{
    private readonly List<GuideMaterial> _all = GuideData.Create();

    public GuideViewModel()
    {
        Chips = new ObservableCollection<FilterChip>(
            new[] { "All" }.Concat(Categories.All).Select(n => new FilterChip(n, n == "All")));

        SelectChipCommand = new Command<FilterChip>(chip =>
        {
            if (chip == null) return;
            foreach (var c in Chips) c.IsSelected = c == chip;
            _filter = chip.Name;
            ApplyFilter();
        });

        // Accordion: opening one card closes the others.
        ToggleCommand = new Command<GuideMaterial>(material =>
        {
            if (material == null) return;
            var open = !material.IsExpanded;
            foreach (var m in _all) m.IsExpanded = false;
            material.IsExpanded = open;
        });

        HelpCommand = new Command(async () => await AlertAsync(
            "How to use the guide",
            "Search for an item, or tap a material chip to filter. Tap a card to open its step-by-step " +
            "preparation checklist."));

        _all[0].IsExpanded = true;   // first card starts open, like the M2 wireframe
        ApplyFilter();
    }

    public ObservableCollection<FilterChip> Chips { get; }
    public ObservableCollection<GuideMaterial> Materials { get; } = new();

    public ICommand SelectChipCommand { get; }
    public ICommand ToggleCommand { get; }
    public ICommand HelpCommand { get; }

    public string Tip => GuideData.Tip;

    private string _filter = "All";

    private string _searchText = string.Empty;
    public string SearchText
    {
        get => _searchText;
        set { if (Set(ref _searchText, value)) ApplyFilter(); }
    }

    private bool _hasResults = true;
    public bool HasResults
    {
        get => _hasResults;
        set { if (Set(ref _hasResults, value)) OnPropertyChanged(nameof(HasNoResults)); }
    }
    public bool HasNoResults => !HasResults;

    private void ApplyFilter()
    {
        var q = SearchText.Trim();

        var result = _all.Where(m =>
            (_filter == "All" || m.Category == _filter) &&
            (q.Length == 0 ||
             m.Category.Contains(q, StringComparison.OrdinalIgnoreCase) ||
             m.Tags.Any(t => t.Contains(q, StringComparison.OrdinalIgnoreCase)) ||
             m.Examples.Any(e => e.Contains(q, StringComparison.OrdinalIgnoreCase)) ||
             m.Steps.Any(s => s.Contains(q, StringComparison.OrdinalIgnoreCase))));

        Materials.Clear();
        foreach (var m in result) Materials.Add(m);
        HasResults = Materials.Count > 0;
    }
}
