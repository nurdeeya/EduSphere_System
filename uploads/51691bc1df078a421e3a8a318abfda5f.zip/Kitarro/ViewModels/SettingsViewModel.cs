using System.Text;
using System.Windows.Input;
using Kitarro.Services;

namespace Kitarro.ViewModels;

public class SettingsViewModel : BaseViewModel
{
    private readonly DatabaseService _db;
    private readonly SessionService _session;
    private readonly SettingsService _settings;

    public SettingsViewModel(DatabaseService db, SessionService session, SettingsService settings)
    {
        _db = db;
        _session = session;
        _settings = settings;

        PrivacyCommand = new Command(async () => await PrivacyAsync());
        ExportCommand = new Command(async () => await ExportAsync());
        HelpCommand = new Command(async () => await AlertAsync(
            "Help centre",
            "• Log a drop-off: Activity tab > fill in the form > Save.\n" +
            "• Not sure how to prepare an item? Open the Guide tab.\n" +
            "• Find a place to drop off: Stations tab > Navigate.\n" +
            "• Points are 10 to 20 per kg depending on the material."));
        SignOutCommand = new Command(async () => await SignOutAsync());
    }

    public ICommand PrivacyCommand { get; }
    public ICommand ExportCommand { get; }
    public ICommand HelpCommand { get; }
    public ICommand SignOutCommand { get; }

    public string[] Themes => SettingsService.Themes;
    public string[] TextSizes => SettingsService.TextSizes;

    public string AccountName => _session.CurrentUser?.FullName ?? string.Empty;
    public string AccountDetails =>
        _session.CurrentUser == null ? string.Empty : $"{_session.CurrentUser.Email} · {_session.CurrentUser.Community}";
    public string SignOutText => $"Sign out ({_session.CurrentUser?.FirstName})";
    public string Version => $"v{AppInfo.Current.VersionString}";

    public string Theme
    {
        get => _settings.Theme;
        set { _settings.Theme = value; OnPropertyChanged(); }
    }

    public string TextSize
    {
        get => _settings.TextSize;
        set { _settings.TextSize = value; OnPropertyChanged(); }
    }

    public bool RecyclingReminders
    {
        get => _settings.RecyclingReminders;
        set { _settings.RecyclingReminders = value; OnPropertyChanged(); }
    }

    public bool CommunityUpdates
    {
        get => _settings.CommunityUpdates;
        set { _settings.CommunityUpdates = value; OnPropertyChanged(); }
    }

    public bool LocationServices
    {
        get => _settings.LocationServices;
        set { _settings.LocationServices = value; OnPropertyChanged(); }
    }

    public void Refresh()
    {
        OnPropertyChanged(nameof(AccountName));
        OnPropertyChanged(nameof(AccountDetails));
        OnPropertyChanged(nameof(SignOutText));
    }

    // Privacy controls: let the user wipe their own recycling history.
    private async Task PrivacyAsync()
    {
        var choice = await Shell.Current.DisplayActionSheet(
            "Privacy controls", "Cancel", "Delete all my recycling logs",
            "Your data never leaves this device.");

        if (choice != "Delete all my recycling logs") return;

        var sure = await Shell.Current.DisplayAlert(
            "Delete all logs?", "All drop-off records and Eco-Points will be erased. This cannot be undone.",
            "Delete", "Cancel");
        if (!sure) return;

        await _db.DeleteAllLogsAsync(_session.UserId);
        await AlertAsync("Done", "Your recycling logs were deleted.");
    }

    // Export my data: builds a CSV file and opens the phone's share sheet.
    private async Task ExportAsync()
    {
        try
        {
            var logs = await _db.GetLogsAsync(_session.UserId);
            if (logs.Count == 0)
            {
                await AlertAsync("Export my data", "There is nothing to export yet. Log a drop-off first.");
                return;
            }

            var sb = new StringBuilder("Date,Category,WeightKg,Points,Location\n");
            foreach (var l in logs)
            {
                var place = CsvQuote(l.Location);
                sb.AppendLine($"{l.Date:yyyy-MM-dd},{l.Category},{l.WeightKg:0.#},{l.Points},{place}");
            }

            var path = Path.Combine(FileSystem.CacheDirectory, "kitarro-recycling-log.csv");
            await File.WriteAllTextAsync(path, sb.ToString());

            await Share.Default.RequestAsync(new ShareFileRequest
            {
                Title = "Export my Kitarro data",
                File = new ShareFile(path)
            });
        }
        catch (Exception ex)
        {
            await AlertAsync("Export failed", ex.Message);
        }
    }

    /// <summary>Wraps text in quotes for CSV and doubles any quote inside it.</summary>
    private static string CsvQuote(string text)
    {
        var q = '"'.ToString();
        return q + text.Replace(q, q + q) + q;
    }

    private async Task SignOutAsync()
    {
        var ok = await Shell.Current.DisplayAlert("Sign out", "Do you want to sign out of Kitarro?", "Sign out", "Cancel");
        if (!ok) return;

        _session.SignOut();
        await Shell.Current.GoToAsync("//login");
    }
}
