using System.Net.Mail;
using System.Windows.Input;
using Kitarro.Helpers;
using Kitarro.Models;
using Kitarro.Services;

namespace Kitarro.ViewModels;

public class SignupViewModel : BaseViewModel
{
    private readonly DatabaseService _db;
    private readonly SessionService _session;

    public SignupViewModel(DatabaseService db, SessionService session)
    {
        _db = db;
        _session = session;

        CreateAccountCommand = new Command(async () => await CreateAccountAsync());
        TogglePasswordCommand = new Command(() => IsPasswordHidden = !IsPasswordHidden);
        ToggleConfirmCommand = new Command(() => IsConfirmHidden = !IsConfirmHidden);
        GoToLoginCommand = new Command(async () => await Shell.Current.GoToAsync("//login"));
        ShowTermsCommand = new Command(async () => await AlertAsync(
            "Terms of Service & Privacy Policy",
            "Kitarro stores your name, email and recycling logs only on this device, in a local database. " +
            "Your password is saved as a salted hash. Nothing is uploaded or shared. " +
            "Eco-points are for personal motivation and have no cash value."));
    }

    private string _fullName = string.Empty;
    public string FullName { get => _fullName; set => Set(ref _fullName, value); }

    private string _email = string.Empty;
    public string Email { get => _email; set => Set(ref _email, value); }

    private string _password = string.Empty;
    public string Password { get => _password; set => Set(ref _password, value); }

    private string _confirm = string.Empty;
    public string Confirm { get => _confirm; set => Set(ref _confirm, value); }

    private bool _acceptTerms;
    public bool AcceptTerms { get => _acceptTerms; set => Set(ref _acceptTerms, value); }

    private bool _isPasswordHidden = true;
    public bool IsPasswordHidden
    {
        get => _isPasswordHidden;
        set { if (Set(ref _isPasswordHidden, value)) OnPropertyChanged(nameof(PasswordToggleText)); }
    }

    private bool _isConfirmHidden = true;
    public bool IsConfirmHidden
    {
        get => _isConfirmHidden;
        set { if (Set(ref _isConfirmHidden, value)) OnPropertyChanged(nameof(ConfirmToggleText)); }
    }

    public string PasswordToggleText => IsPasswordHidden ? "Show" : "Hide";
    public string ConfirmToggleText => IsConfirmHidden ? "Show" : "Hide";

    private string _error = string.Empty;
    public string Error { get => _error; set => Set(ref _error, value); }

    public ICommand CreateAccountCommand { get; }
    public ICommand TogglePasswordCommand { get; }
    public ICommand ToggleConfirmCommand { get; }
    public ICommand GoToLoginCommand { get; }
    public ICommand ShowTermsCommand { get; }

    public void Reset()
    {
        FullName = Email = Password = Confirm = Error = string.Empty;
        AcceptTerms = false;
        IsPasswordHidden = IsConfirmHidden = true;
    }

    /// <summary>Returns an error message, or an empty string when the form is valid.</summary>
    private string Validate()
    {
        if (string.IsNullOrWhiteSpace(FullName) || FullName.Trim().Length < 2)
            return "Please enter your full name.";

        if (!IsValidEmail(Email))
            return "Please enter a valid email address.";

        if (Password.Length < 8 || !Password.Any(char.IsLetter) || !Password.Any(char.IsDigit))
            return "Password needs at least 8 characters with a letter and a number.";

        if (Password != Confirm)
            return "Passwords do not match.";

        if (!AcceptTerms)
            return "Please accept the Terms of Service and Privacy Policy.";

        return string.Empty;
    }

    private static bool IsValidEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email)) return false;
        try
        {
            var addr = new MailAddress(email.Trim());
            return addr.Address == email.Trim() && email.Contains('.');
        }
        catch { return false; }
    }

    private async Task CreateAccountAsync()
    {
        Error = Validate();
        if (Error.Length > 0) return;

        IsBusy = true;
        try
        {
            if (await _db.GetUserByEmailAsync(Email) != null)
            {
                Error = "An account with this email already exists. Try logging in.";
                return;
            }

            var salt = PasswordHasher.NewSalt();
            var user = new User
            {
                FullName = FullName.Trim(),
                Email = Email.Trim(),
                Salt = salt,
                PasswordHash = PasswordHasher.Hash(Password, salt)
            };
            await _db.AddUserAsync(user);

            _session.SignIn(user);
            Haptic();
            await Shell.Current.GoToAsync("//main/home");
        }
        catch (Exception ex)
        {
            Error = "Could not create the account: " + ex.Message;
        }
        finally
        {
            IsBusy = false;
        }
    }
}
