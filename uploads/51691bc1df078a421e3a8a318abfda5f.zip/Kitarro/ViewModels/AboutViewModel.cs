using System.Windows.Input;

namespace Kitarro.ViewModels;

/// <summary>About page: application overview, developer, version and references (assignment requirement).</summary>
public class AboutViewModel : BaseViewModel
{
    public AboutViewModel()
    {
        OpenLinkCommand = new Command<string>(async url =>
        {
            if (string.IsNullOrWhiteSpace(url)) return;
            try { await Launcher.Default.OpenAsync(new Uri(url)); }
            catch (Exception ex) { await AlertAsync("Link", "Could not open the link: " + ex.Message); }
        });
    }

    public ICommand OpenLinkCommand { get; }

    public string AppName => "KITARRO";
    public string Subtitle => "Smart Community Recycling Assistant";
    public string Version => $"v{AppInfo.Current.VersionString}";

    public string Purpose =>
        "Kitarro helps Malaysian households sort recyclables correctly, find nearby drop-off stations and " +
        "track their recycling habits. It supports UN Sustainable Development Goal 9 (Industry, Innovation " +
        "and Infrastructure), Target 9.4: resource-use efficiency.";

    public string DeveloperName => "Muhammad Irham Danish Bin Zapri";
    public string StudentId => "BSW01085836";
    public string Course => "CSNB544 Mobile Application Development";

    public string Footer => "Designed for accessible, responsible community use.";
}
