using System.Windows.Input;
using Kitarro.Helpers;
using Kitarro.Services;

namespace Kitarro.ViewModels;

public class LoginViewModel : BaseViewModel
{
    private readonly DatabaseService _db;
    private readonly SessionService _session;

    public LoginViewModel(DatabaseService db, SessionService session)
    {
        _db = db;
        _session = session;

        LoginCommand = new Command(async () => await LoginAsync());
        TogglePasswordCommand = new Command(() => IsPasswordHidden = !IsPasswordHidden);
        ForgotPasswordCommand = new Command(async () => await AlertAsync(
            "Forgot password?",
            "Kitarro keeps your account on this device only, so passwords cannot be reset by email. " +
            "If you cannot remember it, create a new account from the Sign Up screen."));
        GoToSignupCommand = new Command(async () => await Shell.Current.GoToAsync("//signup"));
    }

    private string _email = string.Empty;
    public string Email { get => _email; set => Set(ref _email, value); }

    private string _password = string.Empty;
    public string Password { get => _password; set => Set(ref _password, value); }

    private bool _isPasswordHidden = true;
    public bool IsPasswordHidden
    {
        get => _isPasswordHidden;
        set { if (Set(ref _isPasswordHidden, value)) OnPropertyChanged(nameof(PasswordToggleText)); }
    }

    public string PasswordToggleText => IsPasswordHidden ? "Show" : "Hide";

    private string _error = string.Empty;
    public string Error { get => _error; set => Set(ref _error, value); }

    public ICommand LoginCommand { get; }
    public ICommand TogglePasswordCommand { get; }
    public ICommand ForgotPasswordCommand { get; }
    public ICommand GoToSignupCommand { get; }

    /// <summary>Clears the form every time the screen is shown (for example after signing out).</summary>
    public void Reset()
    {
        Email = string.Empty;
        Password = string.Empty;
        Error = string.Empty;
        IsPasswordHidden = true;
    }

    private async Task LoginAsync()
    {
        Error = string.Empty;

        if (string.IsNullOrWhiteSpace(Email) || string.IsNullOrWhiteSpace(Password))
        {
            Error = "Please enter your email and password.";
            return;
        }

        IsBusy = true;
        try
        {
            var user = await _db.GetUserByEmailAsync(Email);

            // Same message for "no such user" and "wrong password" so we do not reveal which emails exist.
            if (user == null || !PasswordHasher.Verify(Password, user.Salt, user.PasswordHash))
            {
                Error = "Incorrect email or password.";
                return;
            }

            _session.SignIn(user);
            Haptic();
            await Shell.Current.GoToAsync("//main/home");
        }
        catch (Exception ex)
        {
            Error = "Could not log in: " + ex.Message;
        }
        finally
        {
            IsBusy = false;
        }
    }
}
