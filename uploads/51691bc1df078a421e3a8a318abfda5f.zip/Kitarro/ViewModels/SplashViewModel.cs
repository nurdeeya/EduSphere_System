using Kitarro.Services;

namespace Kitarro.ViewModels;

public class SplashViewModel : BaseViewModel
{
    private readonly SessionService _session;

    public SplashViewModel(SessionService session) => _session = session;

    /// <summary>
    /// Screens map: Splash -> Home (returning user, saved session) or Splash -> Login.
    /// The splash is shown for about 2.5 seconds while the saved session is restored.
    /// </summary>
    public async Task<string> DecideNextRouteAsync()
    {
        var restoreTask = _session.RestoreAsync();
        await Task.WhenAll(restoreTask, Task.Delay(2500));
        return restoreTask.Result ? "//main/home" : "//login";
    }
}
