using System.Collections.ObjectModel;
using System.Windows.Input;
using Kitarro.Drawables;
using Kitarro.Models;
using Kitarro.Services;

namespace Kitarro.ViewModels;

/// <summary>Summary and Milestone Tracker (M1 feature 4): totals, impact and badges from the saved logs.</summary>
public class MilestonesViewModel : BaseViewModel
{
    private readonly DatabaseService _db;
    private readonly SessionService _session;

    public MilestonesViewModel(DatabaseService db, SessionService session)
    {
        _db = db;
        _session = session;

        ShareCommand = new Command(async () => await ShareAsync());
        Gauge = new GaugeDrawable();
    }

    public GaugeDrawable Gauge { get; }
    public ObservableCollection<Badge> Badges { get; } = new();
    public ICommand ShareCommand { get; }

    /// <summary>The page calls Invalidate() on the gauge when this fires.</summary>
    public event Action? GaugeChanged;

    private string _totalText = "0 kg Total Recycled";
    public string TotalText { get => _totalText; set => Set(ref _totalText, value); }

    private string _goalText = string.Empty;
    public string GoalText { get => _goalText; set => Set(ref _goalText, value); }

    private string _helperText = string.Empty;
    public string HelperText { get => _helperText; set => Set(ref _helperText, value); }

    private string _treesText = "0";
    public string TreesText { get => _treesText; set => Set(ref _treesText, value); }

    private string _co2Text = "0";
    public string Co2Text { get => _co2Text; set => Set(ref _co2Text, value); }

    private string _unlockedText = "0 of 4 unlocked";
    public string UnlockedText { get => _unlockedText; set => Set(ref _unlockedText, value); }

    public async Task LoadAsync()
    {
        if (_session.CurrentUser == null) return;

        var logs = await _db.GetLogsAsync(_session.UserId);
        var s = StatsService.Build(logs);

        TotalText = $"{s.TotalKg:0.#} kg Total Recycled";
        GoalText = $"Against a {RecyclingSummary.CommunityGoalKg:0} kg community goal";
        HelperText = s.KgToCommunityGoal > 0
            ? $"Only {s.KgToCommunityGoal:0.#} kg to go!"
            : "Community goal reached - amazing!";
        TreesText = s.Trees.ToString();
        Co2Text = s.Co2Kg.ToString("0.#");
        UnlockedText = $"{s.BadgesUnlocked} of {s.Badges.Count} unlocked";

        Gauge.Progress = s.CommunityProgress;
        GaugeChanged?.Invoke();

        Badges.Clear();
        foreach (var b in s.Badges) Badges.Add(b);
    }

    private async Task ShareAsync()
    {
        await Share.Default.RequestAsync(new ShareTextRequest
        {
            Title = "My Kitarro impact",
            Text = $"I've recycled {TotalText.Replace(" Total Recycled", "")} with Kitarro, " +
                   $"saving {TreesText} trees and preventing {Co2Text} kg of CO2. " +
                   "Recycle smarter, together! ♻️"
        });
    }
}
