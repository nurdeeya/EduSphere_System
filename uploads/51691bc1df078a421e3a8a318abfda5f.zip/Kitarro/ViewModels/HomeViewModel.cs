using System.Collections.ObjectModel;
using System.Windows.Input;
using Kitarro.Models;
using Kitarro.Services;

namespace Kitarro.ViewModels;

public class HomeViewModel : BaseViewModel
{
    private readonly DatabaseService _db;
    private readonly SessionService _session;

    public HomeViewModel(DatabaseService db, SessionService session)
    {
        _db = db;
        _session = session;

        RefreshCommand = new Command(async () =>
        {
            await LoadAsync();
            IsRefreshing = false;
        });
        BellCommand = new Command(async () => await AlertAsync("Notifications", GetNotificationText()));
    }

    public ObservableCollection<RecycleLog> RecentLogs { get; } = new();

    public ICommand RefreshCommand { get; }
    public ICommand BellCommand { get; }

    private bool _isRefreshing;
    public bool IsRefreshing { get => _isRefreshing; set => Set(ref _isRefreshing, value); }

    private string _greeting = "Hello";
    public string Greeting { get => _greeting; set => Set(ref _greeting, value); }

    private string _name = string.Empty;
    public string Name { get => _name; set => Set(ref _name, value); }

    private string _initials = "K";
    public string Initials { get => _initials; set => Set(ref _initials, value); }

    private string _pointsText = "0 Eco-Points";
    public string PointsText { get => _pointsText; set => Set(ref _pointsText, value); }

    private string _monthSubtitle = string.Empty;
    public string MonthSubtitle { get => _monthSubtitle; set => Set(ref _monthSubtitle, value); }

    private string _goalTitle = string.Empty;
    public string GoalTitle { get => _goalTitle; set => Set(ref _goalTitle, value); }

    private string _goalValue = string.Empty;
    public string GoalValue { get => _goalValue; set => Set(ref _goalValue, value); }

    private double _goalProgress;
    public double GoalProgress { get => _goalProgress; set => Set(ref _goalProgress, value); }

    private string _goalHelper = string.Empty;
    public string GoalHelper { get => _goalHelper; set => Set(ref _goalHelper, value); }

    private bool _hasRecent;
    public bool HasRecent
    {
        get => _hasRecent;
        set { if (Set(ref _hasRecent, value)) OnPropertyChanged(nameof(HasNoRecent)); }
    }
    public bool HasNoRecent => !HasRecent;

    private string _bellText = string.Empty;

    public async Task LoadAsync()
    {
        var user = _session.CurrentUser;
        if (user == null) return;

        var hour = DateTime.Now.Hour;
        Greeting = hour < 12 ? "Good Morning" : hour < 18 ? "Good Afternoon" : "Good Evening";
        Name = $"Hello, {user.FirstName}!";
        Initials = user.Initials;

        var logs = await _db.GetLogsAsync(user.Id);
        var s = StatsService.Build(logs);

        PointsText = $"{s.TotalPoints} Eco-Points";
        MonthSubtitle = $"{s.MonthKg:0.#} kg recycled this month";

        GoalTitle = DateTime.Today.ToString("MMMM").ToUpper() + " GOAL";
        GoalValue = $"{s.MonthKg:0.#} / {RecyclingSummary.MonthlyGoalKg:0} kg";
        GoalProgress = s.MonthProgress;
        GoalHelper = s.KgToMonthlyGoal > 0
            ? $"{s.KgToMonthlyGoal:0.#} kg more unlocks your monthly bonus."
            : "Monthly goal reached - great work! 🎉";

        _bellText = logs.Count == 0
            ? "Welcome to Kitarro! Log your first drop-off to start earning Eco-Points."
            : s.KgToMonthlyGoal > 0
                ? $"You are {s.KgToMonthlyGoal:0.#} kg away from this month's goal. Keep going!"
                : "You have reached this month's goal. Thank you for keeping your neighbourhood green!";

        RecentLogs.Clear();
        foreach (var log in logs.Take(3)) RecentLogs.Add(log);
        HasRecent = RecentLogs.Count > 0;
    }

    private string GetNotificationText() => string.IsNullOrEmpty(_bellText)
        ? "No new notifications."
        : _bellText;
}
