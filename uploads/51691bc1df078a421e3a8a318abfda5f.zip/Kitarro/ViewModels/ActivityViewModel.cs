using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows.Input;
using Kitarro.Models;
using Kitarro.Services;

namespace Kitarro.ViewModels;

/// <summary>Recycling Activity Log: add, edit and delete drop-offs (M1 feature 3).</summary>
public class ActivityViewModel : BaseViewModel
{
    private readonly DatabaseService _db;
    private readonly SessionService _session;
    private List<RecycleLog> _logs = new();
    private RecycleLog? _editing;

    public ActivityViewModel(DatabaseService db, SessionService session)
    {
        _db = db;
        _session = session;

        SaveCommand = new Command(async () => await SaveAsync());
        EditCommand = new Command<RecycleLog>(BeginEdit);
        DeleteCommand = new Command<RecycleLog>(async l => await DeleteAsync(l));
        CancelEditCommand = new Command(ClearForm);
        ToggleSeeAllCommand = new Command(() =>
        {
            _showAll = !_showAll;
            RefreshHistory();
        });
    }

    public ObservableCollection<RecycleLog> History { get; } = new();
    public string[] CategoryOptions => Categories.All;

    public ICommand SaveCommand { get; }
    public ICommand EditCommand { get; }
    public ICommand DeleteCommand { get; }
    public ICommand CancelEditCommand { get; }
    public ICommand ToggleSeeAllCommand { get; }

    // ---------- Form fields ----------

    private string? _category;
    public string? Category { get => _category; set => Set(ref _category, value); }

    private string _weightText = string.Empty;
    public string WeightText { get => _weightText; set => Set(ref _weightText, value); }

    private DateTime _date = DateTime.Today;
    public DateTime Date { get => _date; set => Set(ref _date, value); }

    public DateTime MaxDate => DateTime.Today;

    private string _location = string.Empty;
    public string Location { get => _location; set => Set(ref _location, value); }

    private string _error = string.Empty;
    public string Error { get => _error; set => Set(ref _error, value); }

    // ---------- Display ----------

    private bool _isEditing;
    public bool IsEditing
    {
        get => _isEditing;
        set
        {
            if (Set(ref _isEditing, value))
            {
                OnPropertyChanged(nameof(SaveButtonText));
                OnPropertyChanged(nameof(FormTitle));
            }
        }
    }

    public string SaveButtonText => IsEditing ? "Update Entry" : "Save Entry to Log";
    public string FormTitle => IsEditing ? "Edit Drop-Off" : "Log New Drop-Off";

    private bool _showAll;
    public string SeeAllText => _showAll ? "Show less" : "See all";

    private string _monthTitle = string.Empty;
    public string MonthTitle { get => _monthTitle; set => Set(ref _monthTitle, value); }

    private string _monthTotal = string.Empty;
    public string MonthTotal { get => _monthTotal; set => Set(ref _monthTotal, value); }

    private string _impactText = string.Empty;
    public string ImpactText { get => _impactText; set => Set(ref _impactText, value); }

    private bool _hasHistory;
    public bool HasHistory
    {
        get => _hasHistory;
        set { if (Set(ref _hasHistory, value)) OnPropertyChanged(nameof(HasNoHistory)); }
    }
    public bool HasNoHistory => !HasHistory;

    // ---------- Load ----------

    public async Task LoadAsync()
    {
        if (_session.CurrentUser == null) return;
        _logs = await _db.GetLogsAsync(_session.UserId);
        RefreshHistory();
    }

    private void RefreshHistory()
    {
        History.Clear();
        foreach (var l in _showAll ? _logs : _logs.Take(5)) History.Add(l);
        HasHistory = _logs.Count > 0;
        OnPropertyChanged(nameof(SeeAllText));

        var s = StatsService.Build(_logs);
        MonthTitle = DateTime.Today.ToString("MMMM") + " total";
        MonthTotal = $"{s.MonthKg:0.#} kg · {s.MonthPoints} pts";

        var latest = _logs.Take(2).ToList();
        ImpactText = latest.Count == 0
            ? "Log your first drop-off to start your impact story."
            : latest.Count == 1
                ? $"Great start - your latest drop-off diverted {latest[0].WeightKg:0.#} kg from landfill."
                : $"Great pace - your two latest drop-offs diverted {latest.Sum(l => l.WeightKg):0.#} kg from landfill.";
    }

    // ---------- Add / edit / delete ----------

    private async Task SaveAsync()
    {
        Error = string.Empty;

        if (string.IsNullOrEmpty(Category))
        {
            Error = "Please choose a category.";
            return;
        }

        // Accept both "3.2" and "3,2".
        var normalized = (WeightText ?? string.Empty).Trim().Replace(',', '.');
        if (!double.TryParse(normalized, NumberStyles.Float, CultureInfo.InvariantCulture, out var kg) || kg <= 0)
        {
            Error = "Enter a weight greater than 0 kg, for example 3.2.";
            return;
        }
        if (kg > 500)
        {
            Error = "That weight looks too large. Please check it (maximum 500 kg).";
            return;
        }
        if (Date.Date > DateTime.Today)
        {
            Error = "The date cannot be in the future.";
            return;
        }

        kg = Math.Round(kg, 1);
        var points = Categories.CalculatePoints(Category, kg);

        try
        {
            if (_editing != null)
            {
                _editing.Category = Category;
                _editing.WeightKg = kg;
                _editing.Date = Date.Date;
                _editing.Location = Location.Trim();
                _editing.Points = points;
                await _db.UpdateLogAsync(_editing);
            }
            else
            {
                await _db.AddLogAsync(new RecycleLog
                {
                    UserId = _session.UserId,
                    Category = Category,
                    WeightKg = kg,
                    Date = Date.Date,
                    Location = Location.Trim(),
                    Points = points
                });
            }

            Haptic();
            var wasEditing = _editing != null;
            ClearForm();
            await LoadAsync();
            await AlertAsync(wasEditing ? "Entry updated" : "Saved!", $"{points} Eco-Points earned for {kg:0.#} kg.");
        }
        catch (Exception ex)
        {
            Error = "Could not save: " + ex.Message;
        }
    }

    private void BeginEdit(RecycleLog? log)
    {
        if (log == null) return;
        _editing = log;
        Category = log.Category;
        WeightText = log.WeightKg.ToString("0.#", CultureInfo.InvariantCulture);
        Date = log.Date;
        Location = log.Location;
        Error = string.Empty;
        IsEditing = true;
    }

    private async Task DeleteAsync(RecycleLog? log)
    {
        if (log == null) return;

        var ok = await Shell.Current.DisplayAlert(
            "Delete entry?", $"{log.Summary} on {log.DateText} will be removed.", "Delete", "Cancel");
        if (!ok) return;

        await _db.DeleteLogAsync(log);
        if (_editing?.Id == log.Id) ClearForm();
        await LoadAsync();
    }

    private void ClearForm()
    {
        _editing = null;
        IsEditing = false;
        Category = null;
        WeightText = string.Empty;
        Date = DateTime.Today;
        Location = string.Empty;
        Error = string.Empty;
    }
}
