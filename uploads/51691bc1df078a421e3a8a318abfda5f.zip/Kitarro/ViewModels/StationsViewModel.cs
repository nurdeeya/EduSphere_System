using System.Collections.ObjectModel;
using System.Windows.Input;
using Kitarro.Models;
using Kitarro.Services;

namespace Kitarro.ViewModels;

public class StationsViewModel : BaseViewModel
{
    private readonly DatabaseService _db;
    private readonly SessionService _session;
    private readonly SettingsService _settings;
    private readonly List<Station> _all = StationData.Create();

    // Reference point for distances: the phone's GPS position, or the city centre until we have one.
    private double _refLat = StationData.CentreLat;
    private double _refLng = StationData.CentreLng;

    public StationsViewModel(DatabaseService db, SessionService session, SettingsService settings)
    {
        _db = db;
        _session = session;
        _settings = settings;

        LocateCommand = new Command(async () => await LocateAsync(showMessages: true));
        FilterCommand = new Command(async () => await PickFilterAsync());
        NavigateToCommand = new Command<Station>(async s => await OpenMapsAsync(s));
        SaveCommand = new Command<Station>(async s => await ToggleSaveAsync(s));
        SelectCommand = new Command<Station>(Select);

        UpdateDistances();
        ApplyFilter();
    }

    public ObservableCollection<Station> Stations { get; } = new();
    public IReadOnlyList<Station> AllStations => _all;

    public ICommand LocateCommand { get; }
    public ICommand FilterCommand { get; }
    public ICommand NavigateToCommand { get; }
    public ICommand SaveCommand { get; }
    public ICommand SelectCommand { get; }

    /// <summary>The map preview listens to this and redraws itself.</summary>
    public event Action? MapChanged;

    public bool HasUserLocation { get; private set; }
    public double UserLat => _refLat;
    public double UserLng => _refLng;

    private string _subtitle = "Petaling Jaya, Selangor";
    public string Subtitle { get => _subtitle; set => Set(ref _subtitle, value); }

    private string _searchText = string.Empty;
    public string SearchText
    {
        get => _searchText;
        set { if (Set(ref _searchText, value)) ApplyFilter(); }
    }

    private string _materialFilter = "All";
    public string MaterialFilter
    {
        get => _materialFilter;
        set
        {
            if (Set(ref _materialFilter, value))
            {
                OnPropertyChanged(nameof(FilterText));
                ApplyFilter();
            }
        }
    }
    public string FilterText => MaterialFilter == "All" ? "Filter: all materials" : $"Filter: {MaterialFilter}";

    private string _countText = string.Empty;
    public string CountText { get => _countText; set => Set(ref _countText, value); }

    private bool _hasResults = true;
    public bool HasResults
    {
        get => _hasResults;
        set { if (Set(ref _hasResults, value)) OnPropertyChanged(nameof(HasNoResults)); }
    }
    public bool HasNoResults => !HasResults;

    private string _selectedName = "Tap a pin to select a station";
    public string SelectedName { get => _selectedName; set => Set(ref _selectedName, value); }

    public async Task LoadAsync()
    {
        if (_session.CurrentUser != null)
        {
            Subtitle = _session.CurrentUser.Community;
            var saved = await _db.GetSavedStationIdsAsync(_session.UserId);
            foreach (var s in _all) s.IsSaved = saved.Contains(s.Id);
        }
        MapChanged?.Invoke();
    }

    // ---------- GPS (MAUI Geolocation API) ----------

    public async Task LocateAsync(bool showMessages)
    {
        if (!_settings.LocationServices)
        {
            if (showMessages)
                await AlertAsync("Location is off", "Turn on Location services in Settings to sort stations by distance.");
            return;
        }

        try
        {
            var status = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
            if (status != PermissionStatus.Granted)
                status = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();

            if (status != PermissionStatus.Granted)
            {
                if (showMessages)
                    await AlertAsync("Permission needed", "Allow location access to see the stations closest to you.");
                return;
            }

            var location = await Geolocation.Default.GetLocationAsync(
                new GeolocationRequest(GeolocationAccuracy.Medium, TimeSpan.FromSeconds(10)));

            if (location == null)
            {
                if (showMessages) await AlertAsync("Location", "Could not get your position. Try again outdoors.");
                return;
            }

            _refLat = location.Latitude;
            _refLng = location.Longitude;
            HasUserLocation = true;
            UpdateDistances();
            ApplyFilter();
        }
        catch (Exception ex)
        {
            if (showMessages) await AlertAsync("Location", "Location is not available: " + ex.Message);
        }
    }

    private void UpdateDistances()
    {
        var from = new Location(_refLat, _refLng);
        foreach (var s in _all)
            s.DistanceKm = Location.CalculateDistance(from, new Location(s.Latitude, s.Longitude), DistanceUnits.Kilometers);
    }

    // ---------- Search, filter, select ----------

    private async Task PickFilterAsync()
    {
        var options = new[] { "All" }.Concat(Categories.All).ToArray();
        var choice = await Shell.Current.DisplayActionSheet("Show stations that accept", "Cancel", null, options);
        if (!string.IsNullOrEmpty(choice) && choice != "Cancel") MaterialFilter = choice;
    }

    private void ApplyFilter()
    {
        var q = SearchText.Trim();

        var list = _all
            .Where(s => MaterialFilter == "All" || s.Accepts.Contains(MaterialFilter))
            .Where(s => q.Length == 0 ||
                        s.Name.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                        s.Address.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                        s.Type.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                        s.Accepts.Any(a => a.Contains(q, StringComparison.OrdinalIgnoreCase)))
            .OrderBy(s => s.DistanceKm ?? double.MaxValue)
            .ToList();

        Stations.Clear();
        foreach (var s in list) Stations.Add(s);

        HasResults = Stations.Count > 0;
        CountText = $"{Stations.Count} near you";
        MapChanged?.Invoke();
    }

    public void Select(Station? station)
    {
        foreach (var s in _all) s.IsSelected = false;
        if (station != null)
        {
            station.IsSelected = true;
            SelectedName = $"{station.Name} · {station.DistanceText}";
            Haptic();
        }
        else
        {
            SelectedName = "Tap a pin to select a station";
        }
        MapChanged?.Invoke();
    }

    // ---------- Navigate (external Maps app) and Save ----------

    private static async Task OpenMapsAsync(Station? station)
    {
        if (station == null) return;
        try
        {
            // Opens Google Maps (or the browser) with directions to the station.
            var uri = new Uri(
                $"https://www.google.com/maps/dir/?api=1&destination={station.Latitude:F6},{station.Longitude:F6}");
            await Launcher.Default.OpenAsync(uri);
        }
        catch (Exception ex)
        {
            await Shell.Current.DisplayAlert("Maps", "Could not open the Maps app: " + ex.Message, "OK");
        }
    }

    private async Task ToggleSaveAsync(Station? station)
    {
        if (station == null || _session.CurrentUser == null) return;
        station.IsSaved = await _db.ToggleSavedStationAsync(_session.UserId, station.Id);
        Haptic();
    }
}
