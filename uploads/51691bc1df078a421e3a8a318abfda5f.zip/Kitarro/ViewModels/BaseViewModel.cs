using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;

namespace Kitarro.ViewModels;

/// <summary>Base class for every view model: raises PropertyChanged so XAML bindings update automatically.</summary>
public abstract class BaseViewModel : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    protected BaseViewModel()
    {
        NavigateCommand = new Command<string>(async route =>
        {
            if (!string.IsNullOrWhiteSpace(route))
                await Shell.Current.GoToAsync(route);
        });
        BackCommand = new Command(async () => await Shell.Current.GoToAsync(".."));
    }

    /// <summary>Navigates to a Shell route, e.g. "//main/guide" (tab) or "milestones" (pushed page).</summary>
    public ICommand NavigateCommand { get; }

    /// <summary>Back arrow on pushed pages (Milestones, Profile, Settings).</summary>
    public ICommand BackCommand { get; }

    protected void OnPropertyChanged([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    protected bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return false;
        field = value;
        OnPropertyChanged(name);
        return true;
    }

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        set => Set(ref _isBusy, value);
    }

    /// <summary>Shows a simple message box on the current page.</summary>
    protected static Task AlertAsync(string title, string message)
        => Shell.Current.DisplayAlert(title, message, "OK");   // DisplayAlert works on .NET 8, 9 and 10

    /// <summary>Short vibration as touch feedback (ignored on devices without a vibrator).</summary>
    protected static void Haptic()
    {
        try { HapticFeedback.Default.Perform(HapticFeedbackType.Click); }
        catch { /* not supported on this device */ }
    }
}
