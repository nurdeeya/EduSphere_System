using System.Windows.Input;
using Kitarro.Services;

namespace Kitarro.ViewModels;

public class ProfileViewModel : BaseViewModel
{
    private readonly DatabaseService _db;
    private readonly SessionService _session;

    public ProfileViewModel(DatabaseService db, SessionService session)
    {
        _db = db;
        _session = session;

        EditProfileCommand = new Command(async () => await EditNameAsync());
        ManageCommand = new Command(async () => await EditCommunityAsync());
        SavedStationsCommand = new Command(async () => await ShowSavedStationsAsync());
    }

    public ICommand EditProfileCommand { get; }
    public ICommand ManageCommand { get; }
    public ICommand SavedStationsCommand { get; }

    private string _initials = "K";
    public string Initials { get => _initials; set => Set(ref _initials, value); }

    private string _fullName = string.Empty;
    public string FullName { get => _fullName; set => Set(ref _fullName, value); }

    private string _memberText = string.Empty;
    public string MemberText { get => _memberText; set => Set(ref _memberText, value); }

    private string _email = string.Empty;
    public string Email { get => _email; set => Set(ref _email, value); }

    private string _community = string.Empty;
    public string Community { get => _community; set => Set(ref _community, value); }

    private string _points = "0";
    public string Points { get => _points; set => Set(ref _points, value); }

    private string _totalKg = "0";
    public string TotalKg { get => _totalKg; set => Set(ref _totalKg, value); }

    private string _badges = "0";
    public string Badges { get => _badges; set => Set(ref _badges, value); }

    private string _rank = "#1";
    public string Rank { get => _rank; set => Set(ref _rank, value); }

    public async Task LoadAsync()
    {
        var user = _session.CurrentUser;
        if (user == null) return;

        Initials = user.Initials;
        FullName = user.FullName;
        MemberText = $"Eco Member · since {user.CreatedAt:yyyy}";
        Email = user.Email;
        Community = user.Community;

        var logs = await _db.GetLogsAsync(user.Id);
        var s = StatsService.Build(logs);
        Points = s.TotalPoints.ToString();
        TotalKg = s.TotalKg.ToString("0.#") + " kg";
        Badges = s.BadgesUnlocked.ToString();

        // Community rank = position among all accounts on this device, by eco-points.
        var allLogs = await _db.GetAllLogsAsync();
        var users = await _db.GetAllUsersAsync();
        var myPoints = s.TotalPoints;
        var ahead = users.Count(u => u.Id != user.Id && allLogs.Where(l => l.UserId == u.Id).Sum(l => l.Points) > myPoints);
        Rank = $"#{ahead + 1}";
    }

    private async Task EditNameAsync()
    {
        var user = _session.CurrentUser;
        if (user == null) return;

        var name = await Shell.Current.DisplayPromptAsync(
            "Edit profile", "Your full name:", "Save", "Cancel", initialValue: user.FullName, maxLength: 60);
        if (string.IsNullOrWhiteSpace(name)) return;

        user.FullName = name.Trim();
        await _db.UpdateUserAsync(user);
        await LoadAsync();
    }

    private async Task EditCommunityAsync()
    {
        var user = _session.CurrentUser;
        if (user == null) return;

        var place = await Shell.Current.DisplayPromptAsync(
            "Community location", "Your neighbourhood or town:", "Save", "Cancel",
            initialValue: user.Community, maxLength: 80);
        if (string.IsNullOrWhiteSpace(place)) return;

        user.Community = place.Trim();
        await _db.UpdateUserAsync(user);
        await LoadAsync();
    }

    private async Task ShowSavedStationsAsync()
    {
        var ids = await _db.GetSavedStationIdsAsync(_session.UserId);
        var saved = StationData.Create().Where(s => ids.Contains(s.Id)).ToList();

        if (saved.Count == 0)
        {
            await AlertAsync("Saved stations", "No saved stations yet. Tap ☆ Save on a station card to bookmark it.");
            return;
        }

        var choice = await Shell.Current.DisplayActionSheet(
            "Saved stations - tap one for directions", "Close", null,
            saved.Select(s => s.Name).ToArray());

        var station = saved.FirstOrDefault(s => s.Name == choice);
        if (station == null) return;

        await Launcher.Default.OpenAsync(new Uri(
            $"https://www.google.com/maps/dir/?api=1&destination={station.Latitude:F6},{station.Longitude:F6}"));
    }
}
