using System.Security.Cryptography;

namespace Kitarro.Helpers;

/// <summary>Passwords are never stored in plain text: PBKDF2 + random salt.</summary>
public static class PasswordHasher
{
    private const int Iterations = 100_000;

    public static string NewSalt() => Convert.ToBase64String(RandomNumberGenerator.GetBytes(16));

    public static string Hash(string password, string salt)
    {
        var bytes = Rfc2898DeriveBytes.Pbkdf2(
            password,
            Convert.FromBase64String(salt),
            Iterations,
            HashAlgorithmName.SHA256,
            32);
        return Convert.ToBase64String(bytes);
    }

    public static bool Verify(string password, string salt, string expectedHash)
        => CryptographicOperations.FixedTimeEquals(
            Convert.FromBase64String(Hash(password, salt)),
            Convert.FromBase64String(expectedHash));
}
