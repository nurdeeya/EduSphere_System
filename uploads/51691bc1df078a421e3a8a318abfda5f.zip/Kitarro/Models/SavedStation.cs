using SQLite;

namespace Kitarro.Models;

/// <summary>A station a user bookmarked (Profile > Saved Stations).</summary>
[Table("saved_stations")]
public class SavedStation
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    [Indexed]
    public int UserId { get; set; }

    public int StationId { get; set; }
}
