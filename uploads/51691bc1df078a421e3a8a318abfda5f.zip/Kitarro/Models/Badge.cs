namespace Kitarro.Models;

/// <summary>Achievement shown in the 2x2 grid on the Milestones page.</summary>
public class Badge
{
    public string Icon { get; set; } = "🏅";
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public double Current { get; set; }
    public double Target { get; set; }
    public DateTime? EarnedOn { get; set; }

    public bool IsUnlocked => Current >= Target;
    public double Progress => Target <= 0 ? 0 : Math.Min(1, Current / Target);
    public string Symbol => IsUnlocked ? Icon : "🔒";

    public string StatusText => IsUnlocked
        ? (EarnedOn is null ? "Earned" : $"Earned {EarnedOn:MMM dd}")
        : $"{Current:0.#} / {Target:0.#}";
}
