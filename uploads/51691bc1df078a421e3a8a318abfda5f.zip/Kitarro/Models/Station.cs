using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Kitarro.Models;

/// <summary>A drop-off station / RVM / buy-back centre shown on the Stations page.</summary>
public class Station : INotifyPropertyChanged
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;          // e.g. "Reverse Vending Machine"
    public string Address { get; set; } = string.Empty;
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string Hours { get; set; } = string.Empty;
    public string[] Accepts { get; set; } = Array.Empty<string>();

    private double? _distanceKm;
    public double? DistanceKm
    {
        get => _distanceKm;
        set { _distanceKm = value; OnChanged(); OnChanged(nameof(DistanceText)); }
    }

    private bool _isSaved;
    public bool IsSaved
    {
        get => _isSaved;
        set { _isSaved = value; OnChanged(); OnChanged(nameof(SaveText)); }
    }

    private bool _isSelected;
    public bool IsSelected
    {
        get => _isSelected;
        set { _isSelected = value; OnChanged(); }
    }

    public string DistanceText => DistanceKm is null ? "-- km" : $"{DistanceKm:0.0} km";
    public string SaveText => IsSaved ? "★ Saved" : "☆ Save";
    public string AcceptsText => string.Join(" · ", Accepts);

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnChanged([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
