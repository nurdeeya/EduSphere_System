using SQLite;

namespace Kitarro.Models;

/// <summary>Registered account stored in the local SQLite database.</summary>
[Table("users")]
public class User
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    public string FullName { get; set; } = string.Empty;

    [Indexed(Unique = true)]
    public string Email { get; set; } = string.Empty;

    public string PasswordHash { get; set; } = string.Empty;
    public string Salt { get; set; } = string.Empty;
    public string Community { get; set; } = "Petaling Jaya, Selangor";
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    /// <summary>"Muhammad Irham" -> "MI" (used for the avatar circle).</summary>
    [Ignore]
    public string Initials
    {
        get
        {
            var parts = FullName.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0) return "K";
            if (parts.Length == 1) return parts[0][..1].ToUpper();
            return (parts[0][..1] + parts[1][..1]).ToUpper();
        }
    }

    [Ignore]
    public string FirstName
    {
        get
        {
            var parts = FullName.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            return parts.Length == 0 ? "friend" : parts[0];
        }
    }
}
