using SQLite;

namespace Kitarro.Models;

/// <summary>One recorded drop-off (Activity log, M1 feature 3).</summary>
[Table("recycle_logs")]
public class RecycleLog
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    [Indexed]
    public int UserId { get; set; }

    public string Category { get; set; } = string.Empty;
    public double WeightKg { get; set; }
    public DateTime Date { get; set; } = DateTime.Today;
    public string Location { get; set; } = string.Empty;
    public int Points { get; set; }

    // ---- Display helpers (not stored in the database) ----
    [Ignore] public string Icon => Categories.IconFor(Category);
    [Ignore] public string WeightText => $"{WeightKg:0.#} kg";
    [Ignore] public string PointsText => $"{Points} pts";
    [Ignore] public string DateText => Date.ToString("MMM dd, yyyy");
    [Ignore] public string Summary => $"{Category} · {WeightText}";
    [Ignore] public string Detail => $"{DateText} · {Points} pts earned";

    [Ignore]
    public string RelativeDate
    {
        get
        {
            var days = (DateTime.Today - Date.Date).Days;
            return days switch
            {
                0 => "Today",
                1 => "Yesterday",
                _ => Date.ToString("MMM dd")
            };
        }
    }
}

/// <summary>The five material categories from the M1 proposal, with points and impact rates.</summary>
public static class Categories
{
    public static readonly string[] All = { "Plastics", "Paper", "Glass", "Metals", "E-waste" };

    public static string IconFor(string category) => category switch
    {
        "Plastics" => "🧴",
        "Paper" => "📦",
        "Glass" => "🍾",
        "Metals" => "🥫",
        "E-waste" => "🔌",
        _ => "♻️"
    };

    /// <summary>Eco-points earned per kilogram. 3.2 kg of plastic = 35 pts, 5.1 kg of paper = 51 pts (as in M2).</summary>
    public static double PointsPerKg(string category) => category switch
    {
        "Plastics" => 11,
        "Paper" => 10,
        "Glass" => 8,
        "Metals" => 15,
        "E-waste" => 20,
        _ => 5
    };

    public static int CalculatePoints(string category, double kg)
        => (int)Math.Round(PointsPerKg(category) * kg, MidpointRounding.AwayFromZero);
}
