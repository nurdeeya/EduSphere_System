using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Kitarro.Models;

/// <summary>One accordion card on the Guide page (Plastics, Paper, Glass, Metals, E-waste).</summary>
public class GuideMaterial : INotifyPropertyChanged
{
    public string Category { get; set; } = string.Empty;
    public string Icon { get; set; } = "♻️";
    public string Status { get; set; } = string.Empty;           // "Accepted · rinse first"
    public string[] Tags { get; set; } = Array.Empty<string>();
    public string[] Steps { get; set; } = Array.Empty<string>();
    public string[] Examples { get; set; } = Array.Empty<string>();

    public string TagsText => string.Join("  ·  ", Tags);

    /// <summary>"1. Empty the bottle\n2. Rinse..." shown when the card is expanded.</summary>
    public string StepsText => string.Join("\n", Steps.Select((s, i) => $"{i + 1}.  {s}"));
    public string ExamplesText => "Examples: " + string.Join(", ", Examples);

    private bool _isExpanded;
    public bool IsExpanded
    {
        get => _isExpanded;
        set { _isExpanded = value; OnChanged(); OnChanged(nameof(ChevronText)); OnChanged(nameof(IsCollapsed)); }
    }

    public bool IsCollapsed => !IsExpanded;
    public string ChevronText => IsExpanded ? "▲" : "▼";

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnChanged([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
