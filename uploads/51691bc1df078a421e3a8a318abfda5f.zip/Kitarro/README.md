# Kitarro – Smart Community Recycling Assistant

CSNB544 Mobile Application Development · Semester 1 2026/2027 · Final project (M3)
Developer: Muhammad Irham Danish Bin Zapri (BSW01085836)

A .NET MAUI (Android) app built from the M1 proposal and the M2 screens map and wireframes.
Supports UN SDG 9, Target 9.4 (resource-use efficiency).

## How to run

1. Install Visual Studio 2022 (17.8+) or 2026 with the **.NET Multi-platform App UI development** workload
   (Windows), plus an Android emulator or a phone with USB debugging.
2. Open `Kitarro.csproj` (or create an empty .NET MAUI solution and add this folder to it).
3. If Visual Studio has a different .NET SDK, change `net9.0-android` in `Kitarro.csproj`
   to `net8.0-android` or `net10.0-android`.
4. Pick an Android emulator and press **F5**. NuGet restores `sqlite-net-pcl` automatically.

First launch: Splash → Login → tap **Sign Up** → create an account → Home.
Accounts and logs are stored in a local SQLite file (`kitarro.db3`) on the device.

## M1 features → where they are in the code

| M1 feature | Page | View model | Notes |
|---|---|---|---|
| Material Prep and Sorting Guide | `GuidePage` | `GuideViewModel`, `Services/GuideData.cs` | search, filter chips, accordion cards |
| Drop-Off Station Directory | `StationsPage` | `StationsViewModel`, `Services/StationData.cs` | search, material filter, GPS distance, map preview, "Navigate" opens the Maps app |
| Recycling Activity Log | `ActivityPage` | `ActivityViewModel` | add / edit / delete, saved in SQLite |
| Summary and Milestone Tracker | `HomePage`, `MilestonesPage` | `HomeViewModel`, `MilestonesViewModel`, `Services/StatsService.cs` | points, totals, impact, 4 badges |
| About page | `AboutPage` | `AboutViewModel` | description, developer, version, references |

## M2 screens map → navigation

`AppShell.xaml` / `AppShell.xaml.cs`

- Splash → Home (saved session) or Login → Sign Up → Home
- Bottom tabs: Home, Guide, Stations, Activity, About
- Pushed pages: Milestones (Home tile / Activity chart button), Profile (Home avatar / About button),
  Settings (Profile gear)
- Settings → Sign out → Login

## Assignment requirements checklist

| Requirement | Where |
|---|---|
| Icon | `Resources/AppIcon/` |
| Splash screen with logo, auto-navigates | `SplashPage` (+ native splash in `Resources/Splash/`) |
| About page | `AboutPage` |
| Pages for features | 11 pages in `Pages/` |
| Data entry | Sign Up, Activity form, Edit profile |
| Data manipulation / feedback | points per kg, totals, monthly goal, CO2 / trees, badges, rank (`StatsService`) |
| Database | SQLite via `sqlite-net-pcl` (`Services/DatabaseService.cs`): `users`, `recycle_logs`, `saved_stations` |
| Gestures | `TapGestureRecognizer` on cards, chips, tiles; tap on the map pins; pull-to-refresh on Home |
| .NET MAUI APIs | Geolocation + Permissions, Launcher, Share, Preferences, HapticFeedback, AppInfo, FileSystem, theme (`UserAppTheme`) |
| Data binding | MVVM: every page binds to its view model (`INotifyPropertyChanged`, `ICommand`, `BindableLayout`) |

## Architecture (for the code walkthrough)

```
Pages/        XAML + tiny code-behind (sets BindingContext, calls LoadAsync in OnAppearing)
ViewModels/   state + commands, one per page (BaseViewModel has PropertyChanged + navigation commands)
Models/       User, RecycleLog, SavedStation (SQLite tables), Station, GuideMaterial, Badge
Services/     DatabaseService (all SQL), SessionService (who is logged in), SettingsService (preferences),
              StatsService (calculations), GuideData / StationData (content)
Drawables/    GaugeDrawable (progress ring), StationMapDrawable (map preview with tappable pins)
Helpers/      PasswordHasher (PBKDF2 + salt), converters
```

Data flow for "Save Entry to Log": `ActivityPage` button → `ActivityViewModel.SaveCommand` → validates the form →
`Categories.CalculatePoints` → `DatabaseService.AddLogAsync` → `LoadAsync` reloads the list →
bindings refresh the history and the monthly total.

Services are registered in `MauiProgram.cs` (dependency injection) and passed to the view models through their
constructors.

## Things to do before the demo

- **Stations are sample data.** `Services/StationData.cs` has five Petaling Jaya entries with approximate
  coordinates. The app labels them "Verified", so replace them with stations you have checked yourself
  (name, hours, coordinates).
- **Points and impact rates are my assumptions**, chosen to match the M2 wireframe numbers
  (3.2 kg plastics = 35 pts, 5.1 kg paper = 51 pts; about 0.256 kg CO2 and 1 tree per 16 kg).
  They are in `Models/RecycleLog.cs` (`Categories`) and `Services/StatsService.cs`. Be ready to explain them.
- **Emulator GPS:** in the emulator's Extended controls → Location, set a point near Petaling Jaya
  (3.1073, 101.6067) to see distances change.
- **Dark mode / text size:** Settings → Appearance & Data / Location & Accessibility.
- Not built because the wireframe only shows them as placeholders: real notifications behind the two
  notification toggles, e-mail password reset, and online sync. Everything is stored on the device.
