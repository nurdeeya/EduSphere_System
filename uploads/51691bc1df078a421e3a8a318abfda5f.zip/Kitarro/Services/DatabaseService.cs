using Kitarro.Models;
using SQLite;

namespace Kitarro.Services;

/// <summary>
/// All SQLite access lives here (M2 screens map: Recycling / Milestones -> Local Database).
/// Tables: users, recycle_logs, saved_stations.
/// </summary>
public class DatabaseService
{
    private SQLiteAsyncConnection? _db;
    private readonly SemaphoreSlim _initLock = new(1, 1);

    private async Task<SQLiteAsyncConnection> GetDbAsync()
    {
        if (_db != null) return _db;

        await _initLock.WaitAsync();
        try
        {
            if (_db == null)
            {
                var path = Path.Combine(FileSystem.AppDataDirectory, "kitarro.db3");
                var db = new SQLiteAsyncConnection(path,
                    SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.SharedCache);

                await db.CreateTableAsync<User>();
                await db.CreateTableAsync<RecycleLog>();
                await db.CreateTableAsync<SavedStation>();
                _db = db;
            }
        }
        finally
        {
            _initLock.Release();
        }
        return _db;
    }

    // ---------------- Users ----------------

    public async Task<User?> GetUserByEmailAsync(string email)
    {
        var db = await GetDbAsync();
        var e = email.Trim().ToLowerInvariant();
        return await db.Table<User>().Where(u => u.Email == e).FirstOrDefaultAsync();
    }

    public async Task<User?> GetUserAsync(int id)
    {
        var db = await GetDbAsync();
        return await db.Table<User>().Where(u => u.Id == id).FirstOrDefaultAsync();
    }

    public async Task<List<User>> GetAllUsersAsync()
    {
        var db = await GetDbAsync();
        return await db.Table<User>().ToListAsync();
    }

    public async Task<int> AddUserAsync(User user)
    {
        var db = await GetDbAsync();
        user.Email = user.Email.Trim().ToLowerInvariant();
        await db.InsertAsync(user);
        return user.Id;
    }

    public async Task UpdateUserAsync(User user)
    {
        var db = await GetDbAsync();
        await db.UpdateAsync(user);
    }

    // ---------------- Recycle logs (data entry) ----------------

    public async Task<List<RecycleLog>> GetLogsAsync(int userId)
    {
        var db = await GetDbAsync();
        // Newest first; ties broken by id so entries added the same day stay in order.
        var logs = await db.Table<RecycleLog>().Where(l => l.UserId == userId).ToListAsync();
        return logs.OrderByDescending(l => l.Date).ThenByDescending(l => l.Id).ToList();
    }

    public async Task<List<RecycleLog>> GetAllLogsAsync()
    {
        var db = await GetDbAsync();
        return await db.Table<RecycleLog>().ToListAsync();
    }

    public async Task AddLogAsync(RecycleLog log)
    {
        var db = await GetDbAsync();
        await db.InsertAsync(log);
    }

    public async Task UpdateLogAsync(RecycleLog log)
    {
        var db = await GetDbAsync();
        await db.UpdateAsync(log);
    }

    public async Task DeleteLogAsync(RecycleLog log)
    {
        var db = await GetDbAsync();
        await db.DeleteAsync(log);
    }

    /// <summary>Privacy control (Settings): removes every log of one user.</summary>
    public async Task DeleteAllLogsAsync(int userId)
    {
        var db = await GetDbAsync();
        await db.ExecuteAsync("DELETE FROM recycle_logs WHERE UserId = ?", userId);
    }

    // ---------------- Saved stations ----------------

    public async Task<List<int>> GetSavedStationIdsAsync(int userId)
    {
        var db = await GetDbAsync();
        var rows = await db.Table<SavedStation>().Where(s => s.UserId == userId).ToListAsync();
        return rows.Select(r => r.StationId).ToList();
    }

    /// <summary>Adds or removes the bookmark. Returns true when the station is saved afterwards.</summary>
    public async Task<bool> ToggleSavedStationAsync(int userId, int stationId)
    {
        var db = await GetDbAsync();
        var existing = await db.Table<SavedStation>()
            .Where(s => s.UserId == userId && s.StationId == stationId)
            .FirstOrDefaultAsync();

        if (existing != null)
        {
            await db.DeleteAsync(existing);
            return false;
        }

        await db.InsertAsync(new SavedStation { UserId = userId, StationId = stationId });
        return true;
    }
}
