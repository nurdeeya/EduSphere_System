namespace Kitarro.Services;

/// <summary>App preferences (Settings page). Stored with MAUI Preferences so they survive restarts.</summary>
public class SettingsService
{
    public static readonly string[] Themes = { "System", "Light", "Dark" };
    public static readonly string[] TextSizes = { "Small", "Medium", "Large" };

    public string Theme
    {
        get => Preferences.Default.Get("theme", "System");
        set { Preferences.Default.Set("theme", value); ApplyTheme(); }
    }

    public string TextSize
    {
        get => Preferences.Default.Get("text_size", "Medium");
        set { Preferences.Default.Set("text_size", value); ApplyTextSize(); }
    }

    public bool RecyclingReminders
    {
        get => Preferences.Default.Get("notif_reminders", true);
        set => Preferences.Default.Set("notif_reminders", value);
    }

    public bool CommunityUpdates
    {
        get => Preferences.Default.Get("notif_community", false);
        set => Preferences.Default.Set("notif_community", value);
    }

    public bool LocationServices
    {
        get => Preferences.Default.Get("location_services", true);
        set => Preferences.Default.Set("location_services", value);
    }

    /// <summary>Applies saved theme and text size. Called once when the app starts.</summary>
    public void ApplyAll()
    {
        ApplyTheme();
        ApplyTextSize();
    }

    private void ApplyTheme()
    {
        if (Application.Current == null) return;
        Application.Current.UserAppTheme = Theme switch
        {
            "Light" => AppTheme.Light,
            "Dark" => AppTheme.Dark,
            _ => AppTheme.Unspecified
        };
    }

    private void ApplyTextSize()
    {
        if (Application.Current == null) return;
        // Every Label uses {DynamicResource BodyFontSize}, so changing this resizes text everywhere.
        Application.Current.Resources["BodyFontSize"] = TextSize switch
        {
            "Small" => 12d,
            "Large" => 17d,
            _ => 14d
        };
    }
}
