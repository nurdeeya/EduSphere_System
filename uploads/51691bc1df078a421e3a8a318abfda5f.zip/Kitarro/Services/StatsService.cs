using Kitarro.Models;

namespace Kitarro.Services;

/// <summary>Everything the dashboard shows, calculated from the saved logs (M1 feature 4: data manipulation).</summary>
public class RecyclingSummary
{
    public const double MonthlyGoalKg = 15;
    public const double CommunityGoalKg = 50;

    public double TotalKg { get; set; }
    public double MonthKg { get; set; }
    public int TotalPoints { get; set; }
    public int MonthPoints { get; set; }
    public int EntryCount { get; set; }
    public int Trees { get; set; }
    public double Co2Kg { get; set; }
    public List<Badge> Badges { get; set; } = new();

    public int BadgesUnlocked => Badges.Count(b => b.IsUnlocked);
    public double MonthProgress => Math.Min(1, MonthKg / MonthlyGoalKg);
    public double CommunityProgress => Math.Min(1, TotalKg / CommunityGoalKg);
    public double KgToMonthlyGoal => Math.Max(0, MonthlyGoalKg - MonthKg);
    public double KgToCommunityGoal => Math.Max(0, CommunityGoalKg - TotalKg);
}

public static class StatsService
{
    // Approximate impact factors used by the Milestones page.
    private const double Co2KgPerKg = 0.256;     // kg CO2 avoided per kg recycled
    private const double KgPerTree = 16;         // kg of paper-equivalent per tree saved

    public static RecyclingSummary Build(IReadOnlyList<RecycleLog> logs)
    {
        var now = DateTime.Today;
        var month = logs.Where(l => l.Date.Year == now.Year && l.Date.Month == now.Month).ToList();
        var total = logs.Sum(l => l.WeightKg);

        var summary = new RecyclingSummary
        {
            TotalKg = total,
            MonthKg = month.Sum(l => l.WeightKg),
            TotalPoints = logs.Sum(l => l.Points),
            MonthPoints = month.Sum(l => l.Points),
            EntryCount = logs.Count,
            Co2Kg = total * Co2KgPerKg,
            Trees = (int)Math.Floor(total / KgPerTree)
        };

        // Oldest first, so we can find the day each badge was earned.
        var ordered = logs.OrderBy(l => l.Date).ThenBy(l => l.Id).ToList();
        double plasticKg = ordered.Where(l => l.Category == "Plastics").Sum(l => l.WeightKg);

        summary.Badges = new List<Badge>
        {
            new()
            {
                Icon = "🌱", Title = "First Drop-Off", Description = "Log your first drop-off",
                Current = ordered.Count, Target = 1,
                EarnedOn = ordered.FirstOrDefault()?.Date
            },
            new()
            {
                Icon = "🧴", Title = "Plastic Buster · 20kg", Description = "Recycle 20 kg of plastics",
                Current = plasticKg, Target = 20,
                EarnedOn = DateReached(ordered, l => l.Category == "Plastics", 20)
            },
            new()
            {
                Icon = "🏆", Title = "Century Sorter · 100kg", Description = "Recycle 100 kg in total",
                Current = total, Target = 100,
                EarnedOn = DateReached(ordered, _ => true, 100)
            },
            new()
            {
                Icon = "🤝", Title = "Community Champion", Description = "Log 30 drop-offs",
                Current = ordered.Count, Target = 30,
                EarnedOn = ordered.Count >= 30 ? ordered[29].Date : null
            }
        };

        return summary;
    }

    /// <summary>The date on which the running total (for logs matching the filter) first reached the target.</summary>
    private static DateTime? DateReached(List<RecycleLog> ordered, Func<RecycleLog, bool> filter, double target)
    {
        double running = 0;
        foreach (var log in ordered.Where(filter))
        {
            running += log.WeightKg;
            if (running >= target) return log.Date;
        }
        return null;
    }
}
