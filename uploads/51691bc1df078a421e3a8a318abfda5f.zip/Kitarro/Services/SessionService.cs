using Kitarro.Models;

namespace Kitarro.Services;

/// <summary>Remembers who is signed in. The user id is kept in Preferences so the app skips Login next launch.</summary>
public class SessionService
{
    private const string UserIdKey = "session_user_id";
    private readonly DatabaseService _db;

    public SessionService(DatabaseService db) => _db = db;

    public User? CurrentUser { get; private set; }

    public bool IsLoggedIn => CurrentUser != null;

    /// <summary>Called by the splash screen: restores the previous session if there is one.</summary>
    public async Task<bool> RestoreAsync()
    {
        var id = Preferences.Default.Get(UserIdKey, 0);
        if (id <= 0) return false;

        CurrentUser = await _db.GetUserAsync(id);
        if (CurrentUser == null) Preferences.Default.Remove(UserIdKey);
        return CurrentUser != null;
    }

    public void SignIn(User user)
    {
        CurrentUser = user;
        Preferences.Default.Set(UserIdKey, user.Id);
    }

    public void SignOut()
    {
        CurrentUser = null;
        Preferences.Default.Remove(UserIdKey);
    }

    /// <summary>Id of the signed-in user, or 0 if nobody is signed in.</summary>
    public int UserId => CurrentUser?.Id ?? 0;
}
