using Kitarro.Models;

namespace Kitarro.Services;

/// <summary>Preparation instructions for the Guide page (M1 feature 1). Kept in code so the app works offline.</summary>
public static class GuideData
{
    public static List<GuideMaterial> Create() => new()
    {
        new GuideMaterial
        {
            Category = "Plastics", Icon = "🧴",
            Status = "Accepted · rinse and remove labels",
            Tags = new[] { "PET #1", "HDPE #2", "Rinse" },
            Examples = new[] { "water bottles", "milk jugs", "detergent bottles" },
            Steps = new[]
            {
                "Empty the container completely.",
                "Rinse with water to remove food or drink residue.",
                "Remove the cap and any label sleeve (de-label PET bottles).",
                "Crush the bottle flat to save space, then put the cap back on.",
                "Keep clean plastics dry until drop-off."
            }
        },
        new GuideMaterial
        {
            Category = "Paper", Icon = "📦",
            Status = "Accepted · keep dry and clean",
            Tags = new[] { "Flatten", "Keep dry" },
            Examples = new[] { "cardboard boxes", "newspapers", "office paper" },
            Steps = new[]
            {
                "Remove plastic wrap, tape and staples where possible.",
                "Flatten cardboard boxes.",
                "Keep paper dry - wet paper cannot be recycled.",
                "Do not include greasy pizza boxes or used tissue.",
                "Tie or stack neatly for collection."
            }
        },
        new GuideMaterial
        {
            Category = "Glass", Icon = "🍾",
            Status = "Accepted · bottles and jars only",
            Tags = new[] { "Rinse", "No ceramics" },
            Examples = new[] { "drink bottles", "sauce jars" },
            Steps = new[]
            {
                "Empty the bottle or jar and rinse it.",
                "Remove metal lids and caps (recycle them as metal).",
                "Do not mix in ceramics, mirrors, light bulbs or drinking glasses.",
                "Handle carefully - wrap broken glass in newspaper and label it."
            }
        },
        new GuideMaterial
        {
            Category = "Metals", Icon = "🥫",
            Status = "Accepted · cans and tins",
            Tags = new[] { "Rinse", "Crush" },
            Examples = new[] { "drink cans", "food tins", "aluminium foil trays" },
            Steps = new[]
            {
                "Empty the can and rinse out food residue.",
                "Lightly crush drink cans to save space.",
                "Only put completely empty aerosol cans in with metals.",
                "Collect aluminium foil into a ball so it is not lost during sorting."
            }
        },
        new GuideMaterial
        {
            Category = "E-waste", Icon = "🔌",
            Status = "Special drop-off · never in the bin",
            Tags = new[] { "Batteries", "Cables", "Devices" },
            Examples = new[] { "phones", "chargers", "small appliances", "batteries" },
            Steps = new[]
            {
                "Never place electronics or batteries in the household bin.",
                "Remove batteries from devices and keep them separate.",
                "Wipe personal data from phones, laptops and storage devices.",
                "Take items to a station that lists E-waste as an accepted material."
            }
        }
    };

    public const string Tip =
        "Rinse, de-label and flatten first. Clean, dry recyclables are the ones that actually get recycled.";
}
