using Kitarro.Models;

namespace Kitarro.Services;

/// <summary>
/// Directory of drop-off points around Petaling Jaya (M1 feature 2).
/// NOTE: this is sample data with approximate coordinates. Before the demo, replace the entries
/// with stations you have verified (names, hours and coordinates).
/// </summary>
public static class StationData
{
    // Default map centre when GPS is off: Petaling Jaya, Selangor.
    public const double CentreLat = 3.1073;
    public const double CentreLng = 101.6067;

    public static List<Station> Create() => new()
    {
        new Station
        {
            Id = 1, Name = "Taman Megah RVM", Type = "Reverse Vending Machine",
            Address = "Taman Megah, Petaling Jaya", Latitude = 3.1196, Longitude = 101.6205,
            Hours = "Daily · 8:00 AM – 10:00 PM",
            Accepts = new[] { "Plastics", "Metals" }
        },
        new Station
        {
            Id = 2, Name = "PJ Community Recycling Centre", Type = "Collection Depot",
            Address = "Seksyen 14, Petaling Jaya", Latitude = 3.1089, Longitude = 101.6350,
            Hours = "Mon–Sat · 9:00 AM – 5:00 PM",
            Accepts = new[] { "Plastics", "Paper", "Glass", "Metals" }
        },
        new Station
        {
            Id = 3, Name = "SS2 Neighbourhood Drop-off", Type = "Community Drop-off Point",
            Address = "SS2, Petaling Jaya", Latitude = 3.1180, Longitude = 101.6200,
            Hours = "Daily · 7:00 AM – 9:00 PM",
            Accepts = new[] { "Paper", "Glass", "Plastics" }
        },
        new Station
        {
            Id = 4, Name = "Kota Damansara Buy-back Centre", Type = "Buy-back Centre",
            Address = "Kota Damansara, Selangor", Latitude = 3.1500, Longitude = 101.5910,
            Hours = "Mon–Fri · 9:00 AM – 6:00 PM",
            Accepts = new[] { "Metals", "Paper", "Plastics" }
        },
        new Station
        {
            Id = 5, Name = "Bandar Utama E-waste Point", Type = "E-waste Collection",
            Address = "Bandar Utama, Petaling Jaya", Latitude = 3.1470, Longitude = 101.6150,
            Hours = "Daily · 10:00 AM – 9:00 PM",
            Accepts = new[] { "E-waste" }
        }
    };
}
