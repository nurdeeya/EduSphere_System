using Kitarro.Pages;
using Kitarro.Services;
using Kitarro.ViewModels;
using Microsoft.Extensions.Logging;

namespace Kitarro;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();

        // Services (one shared instance for the whole app)
        builder.Services.AddSingleton<DatabaseService>();
        builder.Services.AddSingleton<SessionService>();
        builder.Services.AddSingleton<SettingsService>();

        // Pages + view models (new instance each time they are opened)
        builder.Services.AddTransient<SplashPage>();       builder.Services.AddTransient<SplashViewModel>();
        builder.Services.AddTransient<LoginPage>();        builder.Services.AddTransient<LoginViewModel>();
        builder.Services.AddTransient<SignupPage>();       builder.Services.AddTransient<SignupViewModel>();
        builder.Services.AddTransient<HomePage>();         builder.Services.AddTransient<HomeViewModel>();
        builder.Services.AddTransient<GuidePage>();        builder.Services.AddTransient<GuideViewModel>();
        builder.Services.AddTransient<StationsPage>();     builder.Services.AddTransient<StationsViewModel>();
        builder.Services.AddTransient<ActivityPage>();     builder.Services.AddTransient<ActivityViewModel>();
        builder.Services.AddTransient<MilestonesPage>();   builder.Services.AddTransient<MilestonesViewModel>();
        builder.Services.AddTransient<AboutPage>();        builder.Services.AddTransient<AboutViewModel>();
        builder.Services.AddTransient<ProfilePage>();      builder.Services.AddTransient<ProfileViewModel>();
        builder.Services.AddTransient<SettingsPage>();     builder.Services.AddTransient<SettingsViewModel>();

#if DEBUG
        builder.Logging.AddDebug();
#endif
        return builder.Build();
    }
}
